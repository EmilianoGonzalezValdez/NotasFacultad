package subscription;

/*Esta clase abstrae el contenido de una sola suscripcion que ocurre en 
lista de suscripciones que figuran en el archivo de suscrpcion (json) */

public class Subscription{
	
	private String url;
	private String urlType;
 // private String dowload;
	
	public Subscription(String url, String urltype){
		this.url = url;
		this.urlType = urltype;
	}

	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrlType() {
		return urlType;
	}
	public void setUrlType(String urlType) {
		this.urlType = urlType;
	} 
  

	@Override
	public String toString() {
		return "{url=" + getUrl() + ", urlType=" + getUrlType() + "}";
	}
	
	public void prettyPrint(){
		System.out.println(this.toString());
	}

	
	

	
	
	
}
