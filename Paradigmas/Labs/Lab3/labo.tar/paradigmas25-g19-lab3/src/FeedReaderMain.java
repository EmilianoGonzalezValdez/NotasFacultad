import java.io.IOException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.ThreadLocalRandom;

import javax.xml.namespace.QName;
import scala.Tuple2;
import org.apache.spark.api.java.JavaPairRDD;
import feed.Article;
import feed.Feed;
import httpRequest.httpRequester;
import namedEntity.heuristic.Heuristic;
import namedEntity.heuristic.QuickHeuristic;
import namedEntity.heuristic.RandomHeuristic;
import parser.RssParser;
import parser.SubscriptionParser;
import subscription.SingleSubscription;
import namedEntity.NamedEntity;

//imports para spark
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.api.java.JavaSparkContext;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class FeedReaderMain {

	private static final Logger logger = Logger.getLogger(FeedReaderMain.class.getName());

	static {
		try {
			// Configurar el logger
			FileHandler fileHandler = new FileHandler("feed_reader.log", true);
			fileHandler.setFormatter(new SimpleFormatter());
			logger.addHandler(fileHandler);
			logger.setLevel(Level.INFO);
		} catch (IOException e) {
			System.err.println("Error al configurar el logger: " + e.getMessage());
		}
	}

	private static void printHelp(){
		System.out.println("Please, call this program in correct way: FeedReader [-quick] for quick heuristic or");
		System.out.println("FeedReader [-random] for random heuristic");
	}
	

public static void main(String[] args) throws MalformedURLException, 
												  ProtocolException,
												  URISyntaxException,
												  IOException, ParseException {
	logger.info("Iniciando FeedReader v1.0");
	
	SparkSession spark = null;
	JavaSparkContext jsc = null;
	
	try {
		spark = SparkSession
				.builder()
				.appName("FeedReaderMain")
				.master("local[*]")
				.getOrCreate();
				
		jsc = new JavaSparkContext(spark.sparkContext());
		
		System.out.println("************* FeedReader version 1.0 *************");
		
		if (args.length == 0) {
			subscription.Subscription result = readSubscription();
			List<SingleSubscription> subscripciones = result.getSubscriptionsList();
			JavaRDD<SingleSubscription> subscriptionsRDD = jsc.parallelize(subscripciones);

			subscriptionsRDD.foreach(subscription -> {
				try {
					if ("reddit".equals(subscription.getUrlType())){
						return;
					}
					for (int parameter = 0 ; parameter < subscription.getUlrParamsSize(); parameter++){
						try {
							Feed feed = getURLFeed(subscription, parameter);
							if (feed != null && feed.getArticleList() != null && !feed.getArticleList().isEmpty()) {
								synchronized (System.out) {
									feed.prettyPrint();
								}
							}
						} catch (Exception e) {
							logger.warning("Error procesando feed: " + e.getMessage());
						}
					}
				} catch (Exception e) {
					logger.warning("Error procesando suscripción: " + e.getMessage());
				}
			});
		} else if ((args.length == 1) && 
				((args[0].contentEquals("-quick")) || (args[0].contentEquals("-random")))) {
			
			subscription.Subscription result = readSubscription();
			JavaRDD<SingleSubscription> subscriptionsRDD = jsc.parallelize(result.getSubscriptionsList());

			final Heuristic heuristic;
			if (args[0].contentEquals("-quick")){
				heuristic = new QuickHeuristic();
			} else {
				heuristic = new RandomHeuristic();
			}

			JavaRDD<Article> allArticlesRDD = subscriptionsRDD.flatMap(subscription -> {
				List<Article> articles = new ArrayList<>();
				try {
					if (!"reddit".equals(subscription.getUrlType())) {
						for (int parameter = 0; parameter < subscription.getUlrParamsSize(); parameter++) {
							Feed feed = getURLFeed(subscription, parameter);
							if (feed != null) {
								articles.addAll(feed.getArticleList());
							}
						}
					}
				} catch (Exception e) {
					logger.warning("Error procesando suscripción: " + e.getMessage());
				}
				return articles.iterator();
			});

			JavaPairRDD<String, Integer> entityCounts = allArticlesRDD.flatMapToPair(article -> {
				List<Tuple2<String, Integer>> entities = new ArrayList<>();
				try {
					article.computeNamedEntities(heuristic);
					for (NamedEntity ne : article.getNamedEntitys()) {
						entities.add(new Tuple2<>(ne.getName(), 1));
					}
				} catch (Exception e) {
					logger.warning("Error procesando artículo: " + e.getMessage());
				}
				return entities.iterator();
			}).reduceByKey((a, b) -> a + b);

			Map<String, Integer> entityCountMap = entityCounts.collectAsMap();
			entityCountMap.forEach((entity, count) -> 
				System.out.println(entity + ": " + count));
			Article.prettyPrintThemesSummary();
			Article.prettyPrintGral();
			
		} else {
			printHelp();
		}
	} catch (Exception e) {
		logger.severe("Error en la ejecución principal: " + e.getMessage());
	} finally {
		if (jsc != null) jsc.close();
		if (spark != null) spark.stop();
	}
}


	/* FUNCIONES PARA LA MODULARIZACION DEL MAIN -------------------------------------------------------------------- */

	// Leemos subscriptions por defecto
	protected static subscription.Subscription readSubscription() {
		SubscriptionParser parser = new SubscriptionParser();
		subscription.Subscription result = parser.main("config/subscriptions.json"); // cambiado, ya que leia de src
		return result;
	}


	// obtiene el feed listo para imprimir, de un single subscription
	protected static Feed getURLFeed(SingleSubscription singleSub, int parameter) 
															throws MalformedURLException, ProtocolException, 
															IllegalArgumentException, URISyntaxException, IOException {
		logger.info("Obteniendo feed para suscripción: " + singleSub + " con parámetro: " + parameter);
		
		try {
			if (singleSub == null) {
				logger.severe("Suscripción nula");
				return null;
			}

			// Completa el url con el parametro necesario (parameter = indice)
			String urlComplete = singleSub.getFeedToRequest(parameter);
			if (urlComplete == null || urlComplete.trim().isEmpty()) {
				logger.warning("URL inválida para la suscripción: " + singleSub);
				return null;
			}
			
			logger.info("URL completa: " + urlComplete);
			
			// Llamar al httpRequester para obtener el feed del servidor
			httpRequester requester = new httpRequester();
			String feedRss = requester.getFeedRss(urlComplete);
			if (feedRss == null || feedRss.trim().isEmpty()) {
				logger.warning("No se pudo obtener el contenido del feed para: " + urlComplete);
				return null;
			}
			// Llamar al Parser especifico para extraer los datos necesarios
			RssParser rssParser = new RssParser();
			List<Map<String,Object>> urlParsed = rssParser.main(feedRss);
			if (urlParsed == null || urlParsed.isEmpty()) {
				logger.warning("No se pudieron parsear los artículos del feed: " + urlComplete);
				return null;
			}
			// Llamar al constructor Feed
			Feed feed = new Feed(urlComplete);
			if (feed == null) {
				logger.severe("Error al crear el feed para: " + urlComplete);
				return null;
			}
			// Procesar los primeros 5 artículos
			int articlesProcessed = 0;
			for (int a = 0; a < Math.min(5, urlParsed.size()); a++) {
				try {
					Article article = formArticle(urlParsed, a);
					if (article != null) {
						feed.addArticle(article);
						articlesProcessed++;
					}
				} catch (Exception e) {
					logger.warning("Error procesando artículo " + a + " del feed " + urlComplete + ": " + e.getMessage());
				}
			}
			if (articlesProcessed == 0) {
				logger.warning("No se pudo procesar ningún artículo del feed: " + urlComplete);
				return null;
			}
			logger.info("Procesados " + articlesProcessed + " artículos del feed: " + urlComplete);
			return feed;
			
		} catch (Exception e) {
			logger.severe("Error procesando feed para suscripción " + singleSub + ": " + e.getMessage());
			return null;
		}
	}


	// Devuelve el elemento 'indice' de la lista parseada y la organiza en un tipo Article
	protected static Article formArticle(List<Map<String,Object>> parsedList, int indice) {
		try {
			if (parsedList == null || parsedList.isEmpty() || indice < 0 || indice >= parsedList.size()) {
				return null;
			}

			Map<String, Object> articleData = parsedList.get(indice);
			if (articleData == null) {
				return null;
			}
			
			String titulo = articleData.containsKey("Titulo") ? 
				articleData.get("Titulo").toString().trim() : "Sin título";
			String link = articleData.containsKey("Link") ? 
				articleData.get("Link").toString().trim() : "Sin link";
			String descripcion = articleData.containsKey("Descripción") ? 
				articleData.get("Descripción").toString().trim() : "";
			String fechaEnString = articleData.containsKey("Fecha de publicación") ? 
				articleData.get("Fecha de publicación").toString().trim() : new Date().toString();

			Date fecha = RssParser.StringToDate(fechaEnString);
			if (fecha == null) {
				fecha = new Date();
			}

			return new Article(titulo, descripcion, fecha, link);
		} catch (Exception e) {
			return null;
		}
	}

}
