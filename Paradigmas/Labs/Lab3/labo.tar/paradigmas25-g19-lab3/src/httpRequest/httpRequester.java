package httpRequest;

// import para funciones
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.Serializable;
// Exceptions
import java.net.URISyntaxException;
import java.net.MalformedURLException;
import java.io.IOException;
import java.net.ProtocolException;



import java.io.Reader;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/* Esta clase se encarga de realizar efectivamente el pedido de feed al servidor de noticias
 * Leer sobre como hacer una http request en java
 * https://www.baeldung.com/java-http-request
 * */

public class httpRequester implements Serializable {

  private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(httpRequester.class.getName());
	private static final int MAX_RETRIES = 3;
	private static final int INITIAL_RETRY_DELAY = 1000; // 1 segundo
	private static final int TIMEOUT = 5000; // 5 segundos
	
	// Patrones para validar URLs y contenido
	private static final Pattern URL_PATTERN = Pattern.compile(
		"^https?://[\\w\\d\\-]+(\\.[\\w\\d\\-]+)+([\\w\\d\\-.,@?^=%&:/~+#]*[\\w\\d\\-@?^=%&/~+#])?$"
	);
	
	private static final Pattern CONTENT_PATTERN = Pattern.compile(
		"<(rss|feed|channel)[^>]*>.*?</(rss|feed|channel)>",
		Pattern.DOTALL | Pattern.CASE_INSENSITIVE
	);

	public String getFeedRss(String url) {
		try {
			URL feedUrl = new URL(url);
			HttpURLConnection connection = (HttpURLConnection) feedUrl.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("User-Agent", "Mozilla/5.0");
			
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
				StringBuilder content = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					content.append(line);
				}
				return content.toString();
			}
		} catch (Exception e) {
			return null;
		}
	}

	private boolean isValidUrl(String url) {
		return URL_PATTERN.matcher(url).matches();
	}

	private boolean isValidFeedContent(String content) {
		if (content == null || content.trim().isEmpty()) {
			return false;
		}
		
		// Verificar si el contenido parece un feed XML válido
		return CONTENT_PATTERN.matcher(content).find();
	}

	public String getFeedReedit(String urlFeed) {
		String feedReeditJson = null;
		return feedReeditJson;
	}

}
