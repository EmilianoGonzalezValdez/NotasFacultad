package httpRequest;

// Exceptions
import java.net.URISyntaxException;
import java.net.MalformedURLException;
import java.io.IOException;
import java.net.ProtocolException;

public class httpRequesterTest {
    public static void main(String[] args) {
        // Crear instancia del httpRequester
        httpRequester requester = new httpRequester();
        
        // URL de prueba (feed RSS del NY Times)
        String testUrl = "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml";
        
        try {
            System.out.println("Probando la función getFeedRss con URL: " + testUrl);
            
            // Llamar a la función a testear
            String rssContent = requester.getFeedRss(testUrl);
            
            // Verificar resultados
            if (rssContent == null || rssContent.isEmpty()) {
                System.out.println("Error: El contenido RSS está vacío");
            } else {
                System.out.println("Prueba exitosa! Se obtuvo el feed RSS correctamente.");
                System.out.println("Primeras 200 caracteres del contenido:");
                System.out.println(rssContent.substring(0, Math.min(200, rssContent.length())) + "...");
                
                // Verificación básica de que es un XML
                if (rssContent.contains("<rss") || rssContent.contains("<feed")) {
                    System.out.println("El contenido parece ser un feed RSS/XML válido");
                } else {
                    System.out.println("Advertencia: El contenido no parece ser un feed RSS/XML válido");
                }
            }
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }
    }
}