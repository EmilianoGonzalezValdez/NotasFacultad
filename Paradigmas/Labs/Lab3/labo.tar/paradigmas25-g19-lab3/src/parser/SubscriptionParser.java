package parser;

import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.json.JSONTokener;

import subscription.SingleSubscription;
import subscription.Subscription;
import java.io.Serializable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//imports de librerias con las implementaciones especificas


/*
 * Esta clase implementa el parser del  archivo de suscripcion (json)
 * Leer https://www.w3docs.com/snippets/java/how-to-parse-json-in-java.html
 * */

public class SubscriptionParser extends GeneralParser implements Serializable {
  private static final long serialVersionUID = 1L;
    //is .JSON?


    //Copy from JSON file to Array
    public static JSONArray JsontoArray (String inputFile){
        try{
            FileReader reader = new FileReader(inputFile);
            JSONTokener token = new JSONTokener(reader);
            JSONArray array = new JSONArray(token);
            reader.close();
            return array;
            }
        catch (IOException e){
            throw new RuntimeException("Error reading or parsing file: " + e.getMessage(), e);

        }
    }

    //Obtains the specified data from the array
    public  Subscription JsonParser (JSONArray input){
        System.out.println("Parseando array a estructura de datos");
        
        List<Map<String, Object>> parsed = new ArrayList<>();
        Subscription urlsparsedList = new Subscription(null); 
        
        JSONArray array = input;             
        
        for (int i = 0; i < array.length(); i++) {
            JSONObject data = array.getJSONObject(i);
            String url = data.getString("url");
            String urlType = data.getString("urlType");
            
            SingleSubscription urls = new SingleSubscription(url, null, urlType);
            JSONArray params = data.getJSONArray("urlParams");
            for (int k = 0; k < params.length(); k++) {
                urls.setUlrParams(params.getString(k));
            }

            
            urlsparsedList.addSingleSubscription(urls);

        }
        return urlsparsedList;
    }

@Override
    public  Subscription main (String filePath) {

        if (isJson(filePath)){
            JSONArray jarray = JsontoArray(filePath);
            Subscription result = JsonParser (jarray);
            return result;
        }else{
            System.out.println("Introduzca un archivo JSON valido.");
            return null;
        }

    }


    protected boolean isJson(String filePath) {
         return filePath.endsWith(".json");
    }


    // // Create an ArrayList object

    // public static ArrayList CreateArrLst(){
    //     List<Map<String, Object>> parsed = new ArrayList<>();
    //     return parsed;
    // }
}
