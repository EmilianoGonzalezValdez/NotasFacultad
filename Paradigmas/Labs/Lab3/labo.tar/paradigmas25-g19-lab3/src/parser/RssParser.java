package parser;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.io.Serializable;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.StringReader;
import org.xml.sax.InputSource;

// para String to Date
import java.util.Date;

/* Esta clase implementa el parser de feed de tipo rss (xml)
 * https://www.tutorialspoint.com/java_xml/java_dom_parse_document.htm 
 * */

public class RssParser extends GeneralParser implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private static final Logger logger = Logger.getLogger(RssParser.class.getName());
    
    // Formatos de fecha comunes en RSS y Atom
    private static final String[] DATE_FORMATS = {
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy-MM-dd HH:mm:ss",
        "dd/MM/yyyy HH:mm:ss"
    };

    private static final Pattern DATE_PATTERN = Pattern.compile(
        "(\\d{4}-\\d{2}-\\d{2})|" + // yyyy-MM-dd
        "(\\d{2}\\s+[A-Za-z]{3}\\s+\\d{4})|" + // dd MMM yyyy
        "(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})" // yyyy-MM-ddTHH:mm:ss
    );

    protected List<Map<String, Object>> Parser(String xmlContent) {
        if (xmlContent == null || xmlContent.trim().isEmpty()) {
            return null;
        }

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xmlContent)));
            
            List<Map<String, Object>> articles = new ArrayList<>();
            NodeList items = document.getElementsByTagName("item");
            
            for (int i = 0; i < items.getLength(); i++) {
                Element item = (Element) items.item(i);
                Map<String, Object> article = new HashMap<>();
                
                article.put("Titulo", getElementText(item, "title"));
                article.put("Link", getElementText(item, "link"));
                article.put("Descripción", getElementText(item, "description"));
                article.put("Fecha de publicación", getElementText(item, "pubDate"));
                
                articles.add(article);
            }

            return articles;

        } catch (Exception e) {
            return null;
        }
    }

    private boolean isValidFeed(Document document) {
        String rootTag = document.getDocumentElement().getTagName().toLowerCase();
        return rootTag.contains("rss") || rootTag.contains("feed") || rootTag.contains("channel");
    }

    private NodeList getItems(Document document) {
        String rootTag = document.getDocumentElement().getTagName().toLowerCase();
        if (rootTag.contains("rss") || rootTag.contains("channel")) {
            return document.getElementsByTagName("item");
        } else if (rootTag.contains("feed")) {
            return document.getElementsByTagName("entry");
        }
        return null;
    }

    private boolean isValidArticle(Map<String, Object> article) {
        if (article == null) return false;
        
        String title = (String) article.get("Titulo");
        String link = (String) article.get("Link");
        
        return title != null && !title.trim().isEmpty() && 
               link != null && !link.trim().isEmpty();
    }

    private Map<String, Object> parseArticle(Element item) {
        try {
            Map<String, Object> article = new HashMap<>();
            
            // Extraer título
            String title = getElementText(item, "title");
            if (title != null) {
                article.put("Titulo", cleanText(title));
            }

            // Extraer link
            String link = getElementText(item, "link");
            if (link != null) {
                article.put("Link", cleanText(link));
            }

            // Extraer descripción
            String description = getElementText(item, "description", "content", "summary");
            if (description != null) {
                article.put("Descripción", cleanText(description));
            }

            // Extraer fecha
            String date = getElementText(item, "pubDate", "published", "updated", "date");
            if (date != null) {
                article.put("Fecha de publicación", cleanText(date));
            }

            return article;
        } catch (Exception e) {
            logger.warning("Error parseando artículo: " + e.getMessage());
            return null;
        }
    }

    private String getElementText(Element item, String... tagNames) {
        for (String tagName : tagNames) {
            NodeList nodes = item.getElementsByTagName(tagName);
            if (nodes.getLength() > 0) {
                String text = nodes.item(0).getTextContent();
                if (text != null && !text.trim().isEmpty()) {
                    return text.trim();
                }
            }
        }
        return null;
    }

    private String cleanText(String text) {
        if (text == null) return null;
        return text.replaceAll("\\s+", " ").trim();
    }

    public static Date StringToDate(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) {
            return new Date();
        }
        
        for (String format : DATE_FORMATS) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.US);
                return sdf.parse(dateStr);
            } catch (ParseException e) {
                continue;
            }
        }
        return new Date();
    }

    public List<Map<String,Object>> main(String xmlContent) {
        try {
            if (xmlContent == null || xmlContent.trim().isEmpty()) {
                return null;
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xmlContent)));
            
            List<Map<String,Object>> articles = new ArrayList<>();
            NodeList items = document.getElementsByTagName("item");
            
            for (int i = 0; i < items.getLength(); i++) {
                Element item = (Element) items.item(i);
                Map<String, Object> article = new HashMap<>();
                
                article.put("Titulo", getElementText(item, "title"));
                article.put("Link", getElementText(item, "link"));
                article.put("Descripción", getElementText(item, "description"));
                article.put("Fecha de publicación", getElementText(item, "pubDate"));
                
                articles.add(article);
            }
            
            return articles;
        } catch (Exception e) {
            return null;
        }
    }

    private String getElementText(Element parent, String tagName) {
        NodeList nodes = parent.getElementsByTagName(tagName);
        if (nodes.getLength() > 0) {
            return nodes.item(0).getTextContent();
        }
        return "";
    }
}
