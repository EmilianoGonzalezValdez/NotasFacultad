// package parser;

// import java.util.List;
// import java.util.Map;
// import java.io.File;
// import java.io.IOException;
// import java.nio.file.Files;
// import java.nio.file.Path;

// public class RssParserTest {

//     public static void main(String[] args) {
//         System.out.println("=== Iniciando pruebas manuales de RssParser ===");
        
//         testRssParserWithValidXml();
//         testRssParserWithInvalidFile();
//         testMainMethod();
        
//         System.out.println("=== Pruebas completadas ===");
//     }

//     public static void testRssParserWithValidXml() {
//         System.out.println("\n--- Probando con XML válido ---");
        
//         try {
//             // Crear un archivo XML temporal para la prueba
//             String xmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
//                     "<rss>\n" +
//                     "    <item>\n" +
//                     "        <title>Título de prueba</title>\n" +
//                     "        <description>Descripción de prueba</description>\n" +
//                     "        <pubDate>Fecha de prueba</pubDate>\n" +
//                     "        <link>http://ejemplo.com</link>\n" +
//                     "    </item>\n" +
//                     "</rss>";
            
//             Path tempFile = Files.createTempFile("test", ".xml");
//             Files.write(tempFile, xmlContent.getBytes());

//             // Leer el contenido del archivo temporal
//             String fileContent = Files.readString(tempFile);

//             RssParser parser = new RssParser();
//             List<Map<String, Object>> result = parser.rssParser(fileContent);
                
//             if (result == null) {
//                 System.out.println("FALLA: El resultado es nulo");
//                 return;
//             }
            
//             if (result.isEmpty()) {
//                 System.out.println("FALLA: La lista está vacía");
//                 return;
//             }
            
//             Map<String, Object> firstItem = result.get(0);
//             System.out.println("Elemento parseado: " + firstItem);
            
//             if (!"Título de prueba".equals(firstItem.get("Titulo"))) {
//                 System.out.println("FALLA: Título incorrecto");
//             }
            
//             if (!"Descripción de prueba".equals(firstItem.get("Descripción"))) {
//                 System.out.println("FALLA: Descripción incorrecta");
//             }
            
//             System.out.println("ÉXITO: XML válido parseado correctamente");
            
//             // Limpiar el archivo temporal
//             Files.deleteIfExists(tempFile);
            
//         } catch (Exception e) {
//             System.out.println("FALLA: Excepción inesperada - " + e.getMessage());
//             e.printStackTrace();
//         }
//     }

//     public static void testRssParserWithInvalidFile() {
//         System.out.println("\n--- Probando con archivo inválido ---");
        
//         RssParser parser = new RssParser();
//         List<Map<String, Object>> result = parser.rssParser("contenido inválido");
        
//         if (result != null) {
//             System.out.println("FALLA: Se esperaba null para contenido inválido");
//         } else {
//             System.out.println("ÉXITO: Manejo correcto de contenido inválido");
//         }
//     }

//     public static void testMainMethod() {
//         System.out.println("\n--- Probando método main ---");
        
//         try {
//             // Crear un archivo XML temporal para la prueba
//             String xmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
//                     "<rss>\n" +
//                     "    <item>\n" +
//                     "        <title>Otro título</title>\n" +
//                     "        <description>Otra descripción</description>\n" +
//                     "        <pubDate>Otra fecha</pubDate>\n" +
//                     "        <link>http://otro-ejemplo.com</link>\n" +
//                     "    </item>\n" +
//                     "</rss>";
            
//             Path tempFile = Files.createTempFile("test", ".xml");
//             Files.write(tempFile, xmlContent.getBytes());

//             // Leer el contenido del archivo temporal
//             String fileContent = Files.readString(tempFile);

//             RssParser parser = new RssParser();
//             Object result = parser.main(fileContent);
            
//             if (!(result instanceof List)) {
//                 System.out.println("FALLA: El resultado debería ser una List");
//                 return;
//             }
            
//             @SuppressWarnings("unchecked")
//             List<Map<String, Object>> resultList = (List<Map<String, Object>>) result;
            
//             if (resultList.isEmpty()) {
//                 System.out.println("FALLA: La lista no debería estar vacía");
//             } else {
//                 System.out.println("ÉXITO: Método main funciona correctamente");
//                 System.out.println("Resultado: " + resultList.get(0));
//             }
            
//             // Limpiar el archivo temporal
//             Files.deleteIfExists(tempFile);
            
//         } catch (Exception e) {
//             System.out.println("FALLA: Excepción inesperada - " + e.getMessage());
//             e.printStackTrace();
//         }
//     }
// }