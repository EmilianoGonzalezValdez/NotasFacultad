package parser;
import java.io.IOException;
// HERENCIA es un mecanismo de la programación orientada a 
// objetos que permite crear nuevas clases (subclases) basadas
//  en clases existentes (superclases). Las subclases heredan 
//  los atributos y métodos de la superclase, lo que promueve
//   la reutilización de código y facilita la creación de 
//   relaciones jerárquicas entre clases
// una INTERFAZ es un tipo de dato abstracto que define un contrato
//  de métodos para otras clases. Es un mecanismo para lograr 
//  la abstracción y la herencia múltiple, permitiendo que una 
//  clase implemente múltiples interfaces
/*Esta clase modela los atributos y metodos comunes a todos los distintos tipos de parser existentes en la aplicacion*/
public abstract class GeneralParser {

    protected abstract Object main(String filePath);
}

