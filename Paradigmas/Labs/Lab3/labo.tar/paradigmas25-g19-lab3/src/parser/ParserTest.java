// package parser;

// import java.io.IOException;
// import java.util.List;
// import java.util.Map;

// public class ParserTest {
//     public static void main(String[] args) {
//         try {
//             // Create parser instance
//             GeneralParser parser = new SubscriptionParser();
            
//             // Path to your JSON file
//             String filePath = "subscriptions.json";  // Adjust path as needed
            
//             // Parse the file
//             Object result = parser.getParser(filePath);
            
//             // Print the result
//             if (result != null) {
//                 @SuppressWarnings("unchecked")
//                 List<Map<String, Object>> subscriptions = (List<Map<String, Object>>) result;
//                 for (Map<String, Object> sub : subscriptions) {
//                     System.out.println("URL: " + sub.get("url"));
//                     System.out.println("Type: " + sub.get("urlType"));
//                     System.out.println("Params: " + sub.get("urlParams"));
//                     System.out.println("Download: " + sub.get("download"));
//                     System.out.println("----------------------");
//                 }
//             }
//         } catch (IllegalArgumentException e) {
//             System.err.println("Invalid format: " + e.getMessage());
//         } catch (Exception e) {
//             System.err.println("Unexpected error: " + e.getMessage());
//             e.printStackTrace();
//         }
//     }
// }