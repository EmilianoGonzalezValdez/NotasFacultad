package namedEntity.heuristic;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public abstract class Heuristic {
//mapa.put("clave1", Arrays.asList(10, 20));
 private static final Map<String, List<String>> categoryMap = Map.ofEntries(
 	// Organizaciones
 	Map.entry("Microsoft", Arrays.asList("Organizacion","Tecnologia")),
	Map.entry("Apple", Arrays.asList("Organizacion","Tecnologia")),
	Map.entry("Google", Arrays.asList("Organizacion","Tecnologia")),
	Map.entry("Amazon", Arrays.asList("Organizacion","otrosGral")),
	Map.entry("NASA", Arrays.asList("Organizacion","otrosCultura")),
	Map.entry("UNESCO", Arrays.asList("Organizacion","otrosCultura")),
	Map.entry("FIFA", Arrays.asList("Organizacion","Futbol")),
	Map.entry("Alibaba", Arrays.asList("Organizacion","otrosGral")),
	Map.entry("Facebook", Arrays.asList("Organizacion","Tecnologia")),
	Map.entry("Walmart", Arrays.asList("Organizacion","Negocio")),

	// Personas
	Map.entry("Musk", Arrays.asList("Apellido","Tecnologia")),
	Map.entry("Elon", Arrays.asList("Nombre","Tecnologia")),
	Map.entry("Biden", Arrays.asList("Apellido","Internacional")),
	Map.entry("Trump", Arrays.asList("Apellido","Internacional")),
	Map.entry("Messi", Arrays.asList("Apellido","Futbol")),
	Map.entry("Federer", Arrays.asList("Apellido","Tenis")),
	Map.entry("Obama", Arrays.asList("Apellido","Internacional")),
	Map.entry("Einstein", Arrays.asList("Apellido","otrosCultura")),
	Map.entry("Taylor", Arrays.asList("Nombre","Musica")),
	Map.entry("Milei", Arrays.asList("Apellido","Nacional")),
	Map.entry("Shakira", Arrays.asList("Nombre","Musica")),
	Map.entry("Pope", Arrays.asList("Nombre","otrosCultura")),


	// Lugares
	Map.entry("USA", Arrays.asList("Pais","Internacional")),
	Map.entry("US",Arrays.asList("Pais","Internacional")),
	Map.entry("Miami",Arrays.asList("Ciudad","Internacional")),
	Map.entry("Russia", Arrays.asList("Pais","Internacional")),
	Map.entry("Argentina", Arrays.asList("Pais","Nacional")),
	Map.entry("China", Arrays.asList("Pais","Nacional")),
	Map.entry("Germany", Arrays.asList("Pais","Internacional")),
	Map.entry("Tokyo", Arrays.asList("Ciudad","Internacional")),
	Map.entry("NewYork", Arrays.asList("Ciudad","Internacional")),
	Map.entry("London", Arrays.asList("Ciudad","Internacional")),
	Map.entry("Paris", Arrays.asList("Ciudad","Internacional")),
	Map.entry("Mars", Arrays.asList("Otro","otrosGral")),
	Map.entry("Earth", Arrays.asList("Otro","otrosGral")),

	// Eventos
	Map.entry("Olympics", Arrays.asList("Evento","otrosDeportes")),
	Map.entry("WorldCup", Arrays.asList("Evento","Futbol")),
	Map.entry("SuperBowl", Arrays.asList("Evento","otrosDeportes")),
	Map.entry("Eurovision", Arrays.asList("Evento","Musica")),
	Map.entry("WWII", Arrays.asList("Evento","otrosCultura")),
	Map.entry("WWI", Arrays.asList("Evento","otrosCultura")),
	Map.entry("MetGala", Arrays.asList("Evento","otrosGral")),
	Map.entry("ComicCon", Arrays.asList("Evento","otrosGral")),
	Map.entry("CES", Arrays.asList("Evento","Tecnologia")),

	// Productos
	Map.entry("Galaxy", Arrays.asList("Producto","Tecnologia")),
	Map.entry("PlayStation", Arrays.asList("Producto","Tecnologia")),
	Map.entry("MacBook", Arrays.asList("Producto","Tecnologia")),
	Map.entry("Tesla", Arrays.asList("Producto","Tecnologia")),
	Map.entry("Kindle", Arrays.asList("Producto","Tecnologia")),
	Map.entry("CocaCola", Arrays.asList("Producto","otrosGral")),
	Map.entry("iPhone", Arrays.asList("Producto","Tecnologia")),
	Map.entry("Pepsi", Arrays.asList("Producto","otrosGral")),
	Map.entry("Xbox", Arrays.asList("Producto","Tecnologia")),
	Map.entry("AirPods", Arrays.asList("Producto","Tecnologia"))
);

	public  List<String> valores (String entity){
		return categoryMap.get(entity);
	}

 	public  String getCategory(String entity){
		List<String> array = valores(entity);
 		return array.get(0);
 	}
	
	public  String getTheme(String entity){
		List<String> array = valores(entity);
 		return array.get(1);
 	}

	// chequea si el string s pertenece al diccionario (key)
	public static boolean existOnDiccionary(String s){
		return categoryMap.containsKey(s);
	}
	
 	public abstract boolean isEntity(String word);
		
	// public static void main(String[] args){
	//  String prueba = "Miami";
	 
	//  System.out.println(getCategory(prueba));
	//  System.out.println(getTheme(prueba));
	// }
	
	// para tests:
	public static void main(String[] args){
		System.out.println( Heuristic.existOnDiccionary("Apple"));
	}
 }
