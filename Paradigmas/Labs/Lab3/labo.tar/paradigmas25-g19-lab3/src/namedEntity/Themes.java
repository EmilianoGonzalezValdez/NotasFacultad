package namedEntity;

/*Esta clase modela la nocion de entidad nombrada*/

public class Themes {
    String name;
    String theme;
    int frequency;
    int total_themes = 0;

    public Themes(String name, int frequency, String theme){
        this.name = name;
        this.theme = theme;
        this.frequency = frequency;
        total_themes++;
    }
    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public void incFrequency() {
		this.frequency++;
	}

    public int getTotalThemes() {
		return total_themes;
	}

	@Override
	public String toString() {
		return "ObjectTheme [name=" + name + ", theme=" + theme + "]";
	}

    public void prettyPrint(){
		System.out.println("Theme : " + this.getName() + " " + this.getFrequency());
	}

}
