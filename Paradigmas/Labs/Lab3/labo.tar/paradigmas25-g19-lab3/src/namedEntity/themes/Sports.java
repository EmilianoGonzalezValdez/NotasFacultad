package namedEntity.themes;

import namedEntity.Themes;

public class Sports extends Themes{
    public static int deportes = 0;
    
    public static int freq_futbol = 0;
    public static int freq_basquet = 0;
    public static int freq_tenis = 0;
    public static int freq_f1 = 0;
    public static int freq_otrosDeportes = 0;
    
    public Sports(String name, int frequency, String theme) {
        super(name, frequency, theme);
        deportes++;

        //cuenta la frecuencia del subtipo correspondiente
        if(theme == "Futbol"){
            freq_futbol++;
        }else if (theme == "Basquet"){
            freq_basquet++;
        }else if (theme == "Tenis") {
            freq_tenis++;
        }else if (theme == "F1") {
            freq_f1++;
        }else if (theme == "otrosDeportes") {
            freq_otrosDeportes++;
        }
    }

    // get de las cantidades
    public static int cant_deportes(){
        return deportes;
    }
    
    public static int freq_futbol(){
        return freq_futbol;
    }

    public static int freq_basquet(){
        return freq_basquet;
    }

    public static int freq_tenis(){
        return freq_tenis;
    }
    
    public static int freq_f1(){
        return freq_f1;
    }

    public static int freq_otrosDeportes(){
        return freq_otrosDeportes;
    }

}
