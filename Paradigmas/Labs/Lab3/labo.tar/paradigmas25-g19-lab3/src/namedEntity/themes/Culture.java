package namedEntity.themes;

import namedEntity.Themes;

public class Culture extends Themes{
    
    public static int cultura = 0;
    
    public static int freq_cine = 0;
    public static int freq_musica = 0;
    public static int freq_danza = 0;
    public static int freq_otrosCultura = 0;
    
    public Culture(String name, int frequency, String theme) {
        super(name, frequency, theme);
        cultura++;

        if (theme == "Cine") {
            freq_cine++;
        } else if (theme == "Musica") {
            freq_musica++;            
        } else if (theme == "Danza") {
            freq_danza++;            
        } else if (theme == "otrosCultura") {
            freq_otrosCultura++;            
        }
    }

    // get de las cantidades
    public static int cant_cultura(){
        return cultura;
    }
    
    public static int freq_cine(){
        return freq_cine;
    }

    public static int freq_musica(){
        return freq_musica;
    }

    public static int freq_danza(){
        return freq_danza;
    }

    public static int freq_otrosCultura(){
        return freq_otrosCultura;
    }
    
}