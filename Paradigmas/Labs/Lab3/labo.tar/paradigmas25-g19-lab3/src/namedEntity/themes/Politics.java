package namedEntity.themes;

import namedEntity.Themes;

public class Politics extends Themes{
    public static int politica = 0;
    
    public static int freq_internacional = 0;
    public static int freq_nacional = 0;
    public static int freq_otrosPolitica = 0;
    
    public Politics(String name, int frequency, String theme) {
        super(name, frequency, theme);
        politica++;

        if (theme == "Internacional") {
            freq_internacional++;
        } else if (theme == "Nacional") {
            freq_nacional++;
        } else if (theme == "otrosPolitica") {
            freq_otrosPolitica++;            
        }
    }

    // get de las cantidades
    public static int cant_politica(){
        return politica;
    }
    
    public static int freq_internacional(){
        return freq_internacional;
    }

    public static int freq_nacional(){
        return freq_nacional;
    }

    public static int freq_otrosPolitica(){
        return freq_otrosPolitica;
    }

}

