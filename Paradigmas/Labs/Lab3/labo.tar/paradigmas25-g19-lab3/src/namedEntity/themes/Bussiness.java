package namedEntity.themes;

import namedEntity.Themes;

public class Bussiness extends Themes {
    public static int negocio = 0;

    public Bussiness(String name, int frequency, String theme) {
        super(name, frequency, theme);
        negocio++;
    }


    // get de las cantidades
    public static int cant_negocio(){
        return negocio;
    }
    
}
