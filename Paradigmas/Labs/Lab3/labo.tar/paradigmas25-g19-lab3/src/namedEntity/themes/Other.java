package namedEntity.themes;

import namedEntity.Themes;

public class Other extends Themes{
    public static int otrosGral = 0;
    
    public Other(String name, int frequency, String theme) {
        super(name, frequency, theme);
        otrosGral++;
    }

    // get de las cantidades
    public static int cant_otrosGral(){
        return otrosGral;
    }

}
