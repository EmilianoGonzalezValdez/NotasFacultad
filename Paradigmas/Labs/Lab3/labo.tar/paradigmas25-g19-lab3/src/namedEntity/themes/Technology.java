package namedEntity.themes;

import namedEntity.Themes;

public class Technology extends Themes{
    public static int tecnologia = 0;

    public Technology(String name, int frequency, String theme) {
        super(name, frequency, theme);
        tecnologia++;        
    }


    // get de las cantidades
    public static int cant_tecnologia(){
        return tecnologia;
    }

}
