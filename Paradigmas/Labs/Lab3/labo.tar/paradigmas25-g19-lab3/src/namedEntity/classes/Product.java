package namedEntity.classes;

import namedEntity.NamedEntity;

public class Product extends NamedEntity {
    public static int cant_prod = 0;

    public  Product (String name,int frequency){
        super(name,"Producto",frequency);
        cant_prod++;
        NamedEntity.total++;
    }

    @Override
    public String getCategory() {
        return "Producto";
    }

    //devuelve la cantidad total de productos que se crearon
    public static int cant_prod(){
        return cant_prod;
    }

}
