package namedEntity.classes;

import namedEntity.NamedEntity;

public class Place extends NamedEntity {
    public static int lugarId;
    public static int pais;
    public static int ciudad;
    public static int direccion;
    public static int otro;

    public Place(String name, int frequency, String tipo) {
        super(name, "Lugar", frequency);
        lugarId++;
        NamedEntity.total++;
        if (tipo == "pais") {
            pais++;
        } else if (tipo == "ciudad") {
            ciudad++;
        } else if (tipo == "direccion") {
            direccion++;
        } else {
            otro++;
        }
    }


    @Override
    public String getCategory() {
        return "Lugar";
    }

    public static int getLugarId(){
        return lugarId;
    }

    public static int getPais() {
        return pais;
    }
    public static int getCiudad() {
        return ciudad;
    }
    public static int getDireccion() {
        return direccion;
    }
    public static int getOtro() {
        return otro;
    }

}