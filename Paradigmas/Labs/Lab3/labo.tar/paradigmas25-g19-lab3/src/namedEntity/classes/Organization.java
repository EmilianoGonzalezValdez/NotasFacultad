package namedEntity.classes;

import namedEntity.NamedEntity;

public class Organization extends NamedEntity{
    public static int cant_org = 0;
    private String tipo;

    public Organization (String name, int frequency){
        super(name, "Organizacion",frequency);
        cant_org++;
        NamedEntity.total++;
    }

    @Override
    public String getCategory() {
        return "Organización";
    }

    //devuelve la cantidad total de organizaciones que se crearon
    public static int cant_org(){
        return cant_org;
    }    
}
