package namedEntity.classes;

import namedEntity.NamedEntity;

public class Person extends NamedEntity {
    public static int idPersona = 0;
    public static int freq_apellido = 0;
    public static int freq_titulo = 0;
    public static int freq_nombre = 0;

 
    public  Person (String name,int frequency, String noa){
        super(name, "Persona", frequency);
        //contador de personas en general
        idPersona++;
        NamedEntity.total++;

        //cuenta la frecuencia del subtipo correspondiente
        if(noa == "Nombre"){
            freq_nombre++;
        }else if (noa == "Apellido"){
            freq_apellido++;
        }else if (noa == "Titulo") {
            freq_titulo++;
        }
    }

    @Override
    public String getCategory(){
        return "Persona";
    }

    //accede a cuantos titulos fueron encontrados
    public static int cant_personas(){
        return idPersona;
    }


    //accede a cuantos titulos fueron encontrados
    public static int freq_titulo(){
        return freq_titulo;
    }

        //accede a cuantos nombres fueron encontrados
    public static int freq_nombre(){
        return freq_nombre;
    }

        //accede a cuantos apellidos fueron encontrados
    public static int freq_apellido(){
        return freq_apellido;
    }



}
