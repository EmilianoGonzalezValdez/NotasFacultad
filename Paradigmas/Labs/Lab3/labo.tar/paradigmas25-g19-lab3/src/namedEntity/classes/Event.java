package namedEntity.classes;
import namedEntity.NamedEntity;
import java.util.Date;


public class Event extends NamedEntity {
    String canonName;
    Date date;
    public static int cant_event = 0;



    public Event (int frequency, String canonName){
        super(canonName,"Evento",frequency);
        cant_event++;
        setEventName(canonName);
        setDate(date);
        NamedEntity.total++;
    }

    public void setDate(Date newdate){
        this.date = newdate;
    }
    public void setEventName(String newname){
        this.canonName = newname;
    }

    public String getEventName(){
        return this.canonName;
    }
    public Date getEventDate(){
        return this.date;
    }
    //devuelve la cantidad total de eventos que se crearon
    public static int cant_event(){
        return cant_event;
    }    
}
