package feed;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.text.SimpleDateFormat;
import java.util.Locale;

import namedEntity.NamedEntity;
import namedEntity.Themes;
import namedEntity.classes.Event;
import namedEntity.classes.Organization;
import namedEntity.classes.Person;
import namedEntity.classes.Place;
import namedEntity.classes.Product;
import namedEntity.heuristic.Heuristic;
import namedEntity.themes.Bussiness;
import namedEntity.themes.Culture;
import namedEntity.themes.Other;
import namedEntity.themes.Politics;
import namedEntity.themes.Sports;
import namedEntity.themes.Technology;

/*Esta clase modela el contenido de un articulo (ie, un item en el caso del rss feed) */

public class Article implements Serializable {
  private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(Article.class.getName());
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);
	
	private String title;
	private String text;
	private Date publicationDate;
	private String link;
	
	// para named entities
	private List<NamedEntity> namedEntityList = new ArrayList<NamedEntity>();
	// para themes
	private List<Themes> themesList = new ArrayList<Themes>();
	
	
	public Article(String title, String text, Date publicationDate, String link) {
		this.title = title != null ? title.trim() : "Sin título";
		this.text = text != null ? text.trim() : "";
		this.publicationDate = publicationDate != null ? publicationDate : new Date();
		this.link = link != null ? link.trim() : "Sin link";
	}

	private String cleanHtml(String text) {
		if (text == null) return "";
		return text.replaceAll("<[^>]*>", " ")
				   .replaceAll("&[^;]+;", " ")
				   .replaceAll("\\s+", " ")
				   .trim();
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = cleanHtml(title);
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = cleanHtml(text);
	}

	public Date getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(Date publicationDate) {
		this.publicationDate = publicationDate != null ? publicationDate : new Date();
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link != null ? link.trim() : "Sin link";
	}
	
	@Override
	public String toString() {
		return "Article [title=" + title + ", text=" + text + ", publicationDate=" + publicationDate + ", link=" + link
				+ "]";
	}
	
	
	
	public NamedEntity getNamedEntity(String namedEntity){
		for (NamedEntity n: namedEntityList){
			if (n.getName().compareTo(namedEntity) == 0){				
				return n;
			}
		}
		return null;
	}

	public List<NamedEntity> getNamedEntitys(){
		
		return namedEntityList;
	}
	
	public void computeNamedEntities(Heuristic h){
		String text = this.getTitle() + " " +  this.getText();

		//elimina caracteres innecesarios en el texto
		String charsToRemove = ".,;:()'!?\"\n";
		text = text.replaceAll("'s\\b", ""); // Elimina el 's al final de las palabras
		text = text.replaceAll("'s\\b", ""); // (otro ASCII al de arriba)
		for (char c : charsToRemove.toCharArray()) {
			text = text.replace(String.valueOf(c), "");
		}

		//bucle para encontrar entidades 
		for (String s: text.split(" ")) {

			// Si mi palabra se encuentra en el diccionario, entonces es una entidad. 
			// Lo añado a mi lista de entidades y creo su respectivo objeto según su clase
			if (h.isEntity(s) && Heuristic.existOnDiccionary(s)){
				NamedEntity ne = this.getNamedEntity(s);
				if (ne == null) {

					// JERARQUIA NAMED ENTITIES
					String category = h.getCategory(s);
					if (category != null){
						switch (category) {
							case "Nombre": this.namedEntityList.add(new Person(s, 1,"Nombre")); break;
							case "Apellido": this.namedEntityList.add(new Person(s, 1,"Apellido")); break;
							case "Titulo": this.namedEntityList.add(new Person(s, 1,"Titulo")); break;
							case "Organizacion": this.namedEntityList.add(new Organization(s, 1)); break;
							case "Evento": this.namedEntityList.add(new Event(1, s)); break;
							case "Pais": this.namedEntityList.add(new Place(s, 1,"pais")); break;
							case "Ciudad": this.namedEntityList.add(new Place(s, 1,"ciudad")); break;
							case "Otro": this.namedEntityList.add(new Place(s, 1,"otro")); break;
							case "Producto": this.namedEntityList.add(new Product(s, 1)); break;
						}
					
					}

					// JERARQUIA TEMAS
					String tema = h.getTheme(s);
					if (tema != null) {
						switch (tema) {
							// Tecnologia
							case "Tecnologia": this.themesList.add(new Technology(s, 1, "Tecnologia")); break;
							// Negocio
							case "Negocio": this.themesList.add(new Bussiness(s, 1, "Negocio")); break;
							// Cultura
							case "Cine": this.themesList.add(new Culture(s, 1, "Cine")); break;
							case "Musica": this.themesList.add(new Culture(s, 1, "Musica")); break;
							case "Danza": this.themesList.add(new Culture(s, 1, "Danza")); break;
							case "otrosCultura": this.themesList.add(new Culture(s, 1, "otrosCultura")); break;
							// Politica
							case "Internacional": this.themesList.add(new Politics(s, 1, "Internacional")); break;
							case "Nacional": this.themesList.add(new Politics(s, 1, "Nacional")); break;
							case "otrosPolitica": this.themesList.add(new Politics(s, 1, "otrosPolitica")); break;
							// Deportes
							case "Futbol": this.themesList.add(new Sports(s, 1, "Futbol")); break;
							case "Basquet": this.themesList.add(new Sports(s, 1, "Basquet")); break;
							case "Tenis": this.themesList.add(new Sports(s, 1, "Tenis")); break;
							case "F1": this.themesList.add(new Sports(s, 1, "F1")); break;
							case "otrosDeportes": this.themesList.add(new Sports(s, 1, "otrosDeportes")); break;
							// Otros
							case "otrosGral": this.themesList.add(new Other(s, 1, "otrosGral")); break;

						}
					}

				}else {
					ne.incFrequency();
					NamedEntity.total++;

					// JERARQUIA NAMED ENTITIES
					String category = h.getCategory(s);
					switch (category){
						case "Nombre":Person.idPersona++;Person.freq_nombre++;break;
						case "Apellido":Person.idPersona++;Person.freq_apellido++;break;
						case "Titulo":Person.idPersona++;Person.freq_titulo++;break;
						case "Organizacion":Organization.cant_org++;break;
						case "Evento":Event.cant_event++;break;
						case "Pais":Place.lugarId++;Place.pais++;break;
						case "Ciudad":Place.lugarId++;Place.ciudad++;break;
						case "Otro":Place.lugarId++;Place.otro++;break;
						case "Producto":Product.cant_prod++;break;

					}

					// JERARQUIA TEMAS
					String tema = h.getTheme(s);
					switch (tema) {
						// Tecnologia
						case "Tecnologia": Technology.tecnologia++; break;
						// Negocio
						case "Negocio": Bussiness.negocio++; break;
						// Cultura
						case "Cine": Culture.cultura++; Culture.freq_cine++; break;
						case "Musica": Culture.cultura++; Culture.freq_musica++; break;
						case "Danza": Culture.cultura++; Culture.freq_danza++; break;
						case "otrosCultura": Culture.cultura++; Culture.freq_otrosCultura++; break;
						// Politica
						case "Internacional": Politics.politica++; Politics.freq_internacional++; break;
						case "Nacional": Politics.politica++; Politics.freq_nacional++; break;
						case "otrosPolitica": Politics.politica++; Politics.freq_otrosPolitica++; break;
						// Deportes
						case "Futbol": Sports.deportes++; Sports.freq_futbol++; break;
						case "Basquet": Sports.deportes++; Sports.freq_basquet++; break;
						case "Tenis": Sports.deportes++; Sports.freq_tenis++; break;
						case "F1": Sports.deportes++; Sports.freq_f1++; break;
						case "otrosDeportes": Sports.deportes++; Sports.freq_otrosDeportes++; break;
						// Otros
						case "otrosGral": Other.otrosGral++; break;
					}
				}
			}
		} 
	}

	
	public void prettyPrint() {
		System.out.println("----------------------------------------");
		System.out.println("Título: " + title);
		System.out.println("Fecha de publicación: " + DATE_FORMAT.format(publicationDate));
		System.out.println("Link: " + link);
		System.out.println(text.isEmpty() ? "Sin contenido disponible" : text);
		System.out.println("----------------------------------------");
	}

	public void prettyPrintNamedEntities(){
		System.out.println("**********************************************************************************************\n*****************************ENTIDADES NOMBRADAS DETECTADAS***********************************");
		
		System.out.printf("%-15s | %-15s | %-10s%n", "Nombre", "Categoría", "Frecuencia");
		for (NamedEntity ne : namedEntityList){
			String nombre = ne.getName();
			String categoria = (ne instanceof Person) ? "Persona"
								: (ne instanceof Organization) ? "Organizacion"
								: (ne instanceof Event) ? "Evento"
								: (ne instanceof Place) ? "Lugar"
								: (ne instanceof Product) ? "Producto"
								: (ne.getCategory());
			System.out.printf("%-15s | %-15s | %-10d%n", nombre, categoria, ne.getFrequency());

		}
	}

	public void prettyPrintThemes() {
	System.out.println("**********************************************************************************************");
	System.out.println("*************************************TEMAS DETECTADOS*****************************************");

	System.out.printf("%-15s | %-15s | %-10s%n", "Nombre", "Tema", "Frecuencia");
	for (Themes t : themesList){
		System.out.printf("%-15s | %-15s | %-10d%n", t.getName(), t.getTheme(), t.getFrequency());
	}
}


	public static void prettyPrintGral(){
		
		System.out.printf("\n******************RECUENTO DE ENTIDADES TOTALES******************\n");

		System.out.println("Entidades Nombradas Total:" + NamedEntity.total); //aca va el print total
		System.out.println("\nPOR CLASE:");
		System.out.println("-Personas:" + Person.cant_personas());
		System.out.println("-Lugares:" + Place.getLugarId());
		System.out.println("-Organizaciones:" + Organization.cant_org());
		System.out.println("-Eventos:" + Event.cant_event());
		System.out.println("-Productos:" + Product.cant_prod());

		System.out.println("\nPor subclase:");
		System.out.println("  -Lugar:");
		System.out.println("    *Pais:" + Place.getPais());
		System.out.println("    *Ciudad:" + Place.getCiudad());
		System.out.println("    *Dirección:" + Place.getDireccion());
		System.out.println("    *Otro:" + Place.getOtro());
		System.out.println("  -Personas:");
		System.out.println("    *Nombre:" + Person.freq_nombre());
		System.out.println("    *Apellido:" + Person.freq_apellido());
		System.out.println("    *Titulo:" + Person.freq_titulo());

	}

	public static void prettyPrintThemesSummary() {
	System.out.println("\n******************RECUENTO DE TEMAS TOTALES******************");

	System.out.println("  -Tecnología: " + namedEntity.themes.Technology.tecnologia);
	System.out.println("  -Negocio: " + namedEntity.themes.Bussiness.negocio);
	System.out.println("  -Cultura:");
	System.out.println("  		*Cine: " + namedEntity.themes.Culture.freq_cine);
	System.out.println(" 		*Música: " + namedEntity.themes.Culture.freq_musica);
	System.out.println("  		*Danza: " + namedEntity.themes.Culture.freq_danza);
	System.out.println("  		*Otros: " + namedEntity.themes.Culture.freq_otrosCultura);
	System.out.println("  -Política:");
	System.out.println("  		*Internacional: " + namedEntity.themes.Politics.freq_internacional);
	System.out.println("  		*Nacional: " + namedEntity.themes.Politics.freq_nacional);
	System.out.println("  		*Otros: " + namedEntity.themes.Politics.freq_otrosPolitica);
	System.out.println("  -Deportes:");
	System.out.println("  		*Fútbol: " + namedEntity.themes.Sports.freq_futbol);
	System.out.println("  		*Básquet: " + namedEntity.themes.Sports.freq_basquet);
	System.out.println("  		*Tenis: " + namedEntity.themes.Sports.freq_tenis);
	System.out.println("  		*F1: " + namedEntity.themes.Sports.freq_f1);
	System.out.println("  		*Otros: " + namedEntity.themes.Sports.freq_otrosDeportes);
	System.out.println("  -Otros Generales: " + namedEntity.themes.Other.otrosGral);
}

	public static void main(String[] args) {
		  Article a = new Article("This Historically Black University Created Its Own Tech Intern Pipeline",
			  "A new program at Bowie State connects computing students directly with companies, bypassing an often harsh Silicon Valley vetting process",
			  new Date(),
			  "https://www.nytimes.com/2023/04/05/technology/bowie-hbcu-tech-intern-pipeline.html"
			  );
		 
		  a.prettyPrint();
	}
	
	
}



