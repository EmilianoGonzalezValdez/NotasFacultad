package feed;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import namedEntity.NamedEntity;

/*Esta clase modela la lista de articulos de un determinado feed*/
public class Feed implements Serializable {
  private static final long serialVersionUID = 1L;
	String siteName;
	List<Article> articleList;
	
	public Feed(String siteName) {
		super();
		this.siteName = siteName;
		this.articleList = new ArrayList<Article>();
	}

	public String getSiteName(){
		return siteName;
	}
	
	public void setSiteName(String siteName){
		this.siteName = siteName;
	}
	
	public List<Article> getArticleList(){
		return articleList;
	}
	
	public void setArticleList(List<Article> articleList){
		this.articleList = articleList;
	}
	
	public void addArticle(Article a){
		this.getArticleList().add(a);
	}
	
	public Article getArticle(int i){
		return this.getArticleList().get(i);
	}
	
	public int getNumberOfArticles(){
		return this.getArticleList().size();
	}
	
	@Override
	public String toString(){
		return "Feed [siteName=" + getSiteName() + ", articleList=" + getArticleList() + "]";
	}
	

	public void prettyPrint(){
		try {
			String separator = "**********************************************************************************************";
			System.out.println("\n" + separator);
			System.out.println("Feed: " + (this.getSiteName() != null ? this.getSiteName() : "Unknown Site"));
			System.out.println(separator);
			
			List<Article> articles = this.getArticleList();
			if (articles == null) {
				System.out.println("[Feed.prettyPrint] Error: Article list is null");
				return;
			}
			
			if (articles.isEmpty()) {
				System.out.println("[Feed.prettyPrint] No articles found in this feed");
				return;
			}
			
			System.out.println("Number of articles: " + articles.size());
			System.out.println(separator);
			
			for (int i = 0; i < articles.size(); i++) {
				Article a = articles.get(i);
				if (a == null) {
					System.out.println("[Feed.prettyPrint] Warning: Article " + i + " is null");
					continue;
				}
				try {
					System.out.println("\nArticle " + (i + 1));
					System.out.println(separator);
					a.prettyPrint();
					System.out.println(separator);
				} catch (Exception e) {
					System.out.println("[Feed.prettyPrint] Error printing article " + (i + 1) + ": " + e.getMessage());
				}
			}
		} catch (Exception e) {
			System.out.println("[Feed.prettyPrint] Error in prettyPrint: " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		  Article a1 = new Article("This Historically Black University Created Its Own Tech Intern Pipeline",
			  "A new program at Bowie State connects computing students directly with companies, bypassing an often harsh Silicon Valley vetting process",
			  new Date(),
			  "https://www.nytimes.com/2023/04/05/technology/bowie-hbcu-tech-intern-pipeline.html"
			  );
		 
		  Article a2 = new Article("This Historically Black University Created Its Own Tech Intern Pipeline",
				  "A new program at Bowie State connects computing students directly with companies, bypassing an often harsh Silicon Valley vetting process",
				  new Date(),
				  "https://www.nytimes.com/2023/04/05/technology/bowie-hbcu-tech-intern-pipeline.html"
				  );
		  
		  Article a3 = new Article("This Historically Black University Created Its Own Tech Intern Pipeline",
				  "A new program at Bowie State connects computing students directly with companies, bypassing an often harsh Silicon Valley vetting process",
				  new Date(),
				  "https://www.nytimes.com/2023/04/05/technology/bowie-hbcu-tech-intern-pipeline.html"
				  );
		  
		  Feed f = new Feed("nytimes");
		  f.addArticle(a1);
		  f.addArticle(a2);
		  f.addArticle(a3);

		  f.prettyPrint();
		  
	}
	
}
